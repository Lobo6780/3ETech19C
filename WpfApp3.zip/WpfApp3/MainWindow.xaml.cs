﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace WpfApp3
{
	/// <summary>
	/// Logika interakcji dla klasy MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void sprawdzcene_Click(object sender, RoutedEventArgs e)
		{
			if (przesylka0.IsChecked == true)
			{
				zdj.Source = new BitmapImage(new Uri("Images/pocztowka.png", UriKind.Relative));
				cena.Content = "Cena: 1 zł";
			}
			if (przesylka1.IsChecked == true)
			{
				zdj.Source = new BitmapImage(new Uri("Images/list.png", UriKind.Relative));
				cena.Content = "Cena: 1,50 zł";
			}
			if (przesylka2.IsChecked == true)
			{
				zdj.Source = new BitmapImage(new Uri("Images/paczka.png", UriKind.Relative));
				cena.Content = "Cena: 10 zł";
			}
		}

		private void zatwierdz_Click(object sender, RoutedEventArgs e)
		{
			if (Regex.IsMatch(kpoczt.Text, @"^\d{5}$"))
			{
				MessageBox.Show("Dane przesyłki zostały wprowadzone");
			}
			else if (kpoczt.Text.Length > 5 | kpoczt.Text.Length < 5)
			{
				MessageBox.Show("Nieprawidłowa liczba cyfr w kodzie pocztowym");
			}
			else
			{
				MessageBox.Show("Kod pocztowy powinien się składać z samych cyfr");
			}
		}
	}
}
